# RawRack Ecommerce — setup & go-live

## 1. Install
- Install Node.js 20+.
- Open a terminal in this folder.
- Run `npm install`.
- Copy `.env.example` to `.env`.

## 2. Razorpay
Create a Razorpay account and use Test Mode first.
Put your Test Mode Key ID and Secret in `.env`.

The server creates a Razorpay Order before opening Checkout, then verifies the returned payment signature.
For production, configure a public HTTPS webhook at:
`https://YOUR-DOMAIN/api/razorpay/webhook`
and set `RAZORPAY_WEBHOOK_SECRET`.

Before live payments:
- replace Test Mode keys with Live Mode keys;
- configure automatic capture;
- configure webhook events;
- use HTTPS;
- test the complete order/payment/webhook lifecycle.

## 3. Run
`npm start`

Open:
- http://localhost:3000 — storefront
- http://localhost:3000/product.html?id=hoodie — product/customizer
- http://localhost:3000/checkout.html — checkout
- http://localhost:3000/admin.html — order management

## 4. Admin
Set `ADMIN_KEY` in `.env`. Never commit `.env` to GitHub.

## 5. WhatsApp
Customer support uses +91 7022769412.
After successful checkout, the customer gets a prefilled WhatsApp support link.
The admin page also generates a WhatsApp message for each customer's number.

## 6. Product design upload
The prototype accepts PNG/JPG/WEBP files up to 8MB and stores them in `/uploads`.
For a production deployment, move uploads to object storage (Cloudinary/S3/etc.) and add malware scanning, authorization and retention rules.

## 7. What is production-ready vs prototype
Ready in this build:
- server-side product pricing
- cart
- product page
- size/color selection
- design upload
- browser live preview
- order creation
- Razorpay Standard Checkout integration point
- signature verification
- webhook endpoint
- order confirmation
- WhatsApp links
- admin order/status page

Still required before accepting real public orders:
- business/legal details, policies, GST/tax setup as applicable
- real Razorpay account and keys
- HTTPS deployment
- durable production database instead of JSON storage
- cloud image storage
- real inventory and product photography
- shipping workflow
- email/SMS/WhatsApp transactional notifications
- refund/cancellation workflow
- security hardening/rate limiting/backups
