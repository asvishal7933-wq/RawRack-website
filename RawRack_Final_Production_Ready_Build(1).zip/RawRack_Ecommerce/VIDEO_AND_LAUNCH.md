# RawRack — video + proper website link

## Video support
The website now supports responsive HTML5 campaign videos.

Put videos here:
`public/videos/rawrack-campaign.mp4`
`public/videos/rawrack-campaign.webm`

Recommended master:
- Landscape: 1920 × 1080 (16:9)
- Mobile-first/vertical: 1080 × 1920 (9:16)
- Keep the exported web file ideally around 5–20 MB for a normal campaign clip.
- H.264 MP4 is the safest primary format; WebM is an optional secondary format.
- Use `muted` + `playsinline` for mobile-friendly autoplay if you later enable autoplay.
- Keep important text/logos inside the central safe area because the crop changes on phones.

The current website shows the video in a responsive 16:9 desktop container and switches to a 9:16 container on small screens.

## Proper website link
A real public URL cannot be generated from this zip alone because the site needs to be deployed to a hosting provider and, optionally, connected to a domain.

Recommended launch structure:
1. Buy a domain such as `rawrack.in` or `rawrack.com` if available.
2. Deploy the Node/Express app to a host that supports a persistent server and storage.
3. Add the domain in the host dashboard.
4. Point the domain's DNS records to the host.
5. Enable HTTPS.
6. Put Razorpay Live keys in server environment variables.
7. Configure the Razorpay webhook:
   `https://YOUR-DOMAIN/api/razorpay/webhook`

Do NOT put `RAZORPAY_KEY_SECRET`, webhook secrets, or `ADMIN_KEY` in frontend JavaScript.

## Device support
The layout is responsive for:
- Android phones
- iPhones
- tablets
- laptops
- desktops
- large monitors

The navigation collapses on smaller screens, product grids adapt, campaign video changes aspect ratio, checkout becomes one-column, and buttons/inputs remain touch-friendly.

## Before public launch
- Replace the demo/placeholder product visuals with actual product photos.
- Upload the campaign videos.
- Move order storage from JSON to a production database.
- Move uploaded designs to durable object storage.
- Add shipping, returns, privacy and terms pages.
- Configure Razorpay Live Mode and webhooks.
- Test payments on iPhone, Android, Chrome, Safari and desktop.
- Add analytics and SEO/social sharing metadata.
